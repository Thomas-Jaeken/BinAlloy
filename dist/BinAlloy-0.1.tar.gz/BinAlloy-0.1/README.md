# BinAlloy 

## a module to calculate temperature profiles of the long-range order, energy and short-range order in a binary alloy.
## The current version will only let one execute the algortihm for CuZn.
## In the next version, the user will be able to pick metals from a list and even supply custom bond energies.
